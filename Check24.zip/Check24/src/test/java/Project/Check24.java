package Project;

import Testcases.Testcases;
import Testcases.TestcasesRestAssured;
import org.testng.annotations.Test;

public class Check24 {
    @Test(priority = 1, enabled = true)
    public void execution() throws Exception {
        Testcases testcases = new Testcases();
        testcases.openWebsite();
        testcases.verifyCookie();
        testcases.clickOnBarclaysVisa();
        testcases.fillEmailAndNext();
        testcases.chooseIchMochte();
        testcases.showError();
        testcases.verifyError();
        testcases.fillForm();
    }

    @Test(priority = 2, enabled = true)
    public void restAssured() throws Exception {
        TestcasesRestAssured restAssured = new TestcasesRestAssured();
        restAssured.firstId();
        restAssured.secondId();
        restAssured.thirdId();
    }
}