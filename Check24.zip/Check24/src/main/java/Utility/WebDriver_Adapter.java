package Utility;

import Utility.Base;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.IOException;

public class WebDriver_Adapter extends Base {

    public static void waitOnClick(By locator) {

        new WebDriverWait(getDriver(), 60).ignoring(NoSuchElementException.class)
                .until(ExpectedConditions.elementToBeClickable(locator));
    }
    public static void waitVisibilityOfElement(By locator) {

        new WebDriverWait(getDriver(), 60).ignoring(NoSuchElementException.class)
                .until(ExpectedConditions.visibilityOfElementLocated(locator));
    }

    public static void click(By locator) {
        new WebDriverWait(getDriver(), 100).ignoring(NoSuchElementException.class)
                .until(ExpectedConditions.elementToBeClickable(locator));
        getDriver().findElement(locator).click();
    }
    public static void click1(By locator) {
        getDriver().findElement(locator).click();
    }

    public static void type(By locator, String data) {
        new WebDriverWait(getDriver(), 100).ignoring(NoSuchElementException.class)
                .until(ExpectedConditions.visibilityOfElementLocated(locator));
        getDriver().findElement(locator).sendKeys(data);
        logInfo("------ value : "+data);
    }

    public static boolean isElementPresent(By element) {
        try {
            getDriver().findElement(element).isDisplayed();
            return true;
        } catch (NoSuchElementException e) {
            return false;
        }
    }

    public static void click_javaScript(By locator) {
        WebElement element = getDriver().findElement(locator);
        JavascriptExecutor executor = (JavascriptExecutor) getDriver();
        executor.executeScript("arguments[0].click();", element);
    }

    public static void verifyError(String error){
        if(WebDriver_Adapter.isElementPresent(By.xpath("//*[text()='"+error+"']"))==true){
            logInfo("------ error present : "+error);
        }else {
            logInfo("------ error not present : "+error);
        }}

    public static void cookieVerify() throws IOException {
    Cookie cookieval = getDriver().manage().getCookieNamed(propertyFile("cookieKey"));
        if (cookieval.getValue().equalsIgnoreCase(propertyFile("cookieValue"))) {
        logInfo("------ cookie set to ppset=kreditkarte");
    }else {
        logInfo("------ Error : cookie not set to ppset=kreditkarte");
    }}
    public static void lastPageCheck(){
        if(WebDriver_Adapter.isElementPresent(Page_Object_Reader.getElement("err"))==true){
            logInfo("------ error present at last page ");
        }else {
            logInfo("------ error not present at last page  ");
        }}
}