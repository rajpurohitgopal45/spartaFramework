package Listeners;

import Utility.Base;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import java.io.File;
import java.io.IOException;

public class ExtentManager {
    private static ExtentReports extent;
    public static ExtentReports createInstance(String filename) {
        ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter(filename);

        htmlReporter.config().setTheme(Theme.DARK);
        htmlReporter.config().setDocumentTitle(filename);
        htmlReporter.config().setEncoding("utf-8");
        htmlReporter.config().setReportName(filename);

        extent = new ExtentReports();
        extent.attachReporter(htmlReporter);
        extent.setSystemInfo("Organization", "Rand Merchant Bank");
        extent.setSystemInfo("Project", "IBD DCF_Manager");
        return extent;
    }

    public static String captureScreenshot(String screenshotName) {
        File scrFile = ((TakesScreenshot) Base.getDriver()).getScreenshotAs(OutputType.FILE);
        String path = System.getProperty("user.dir") + "\\reports\\" + screenshotName + ".png";
        File destination = new File(path);
        try {
            FileUtils.copyFile(scrFile, destination);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return path;
    }
}